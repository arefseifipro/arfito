// panel.js
// اصلاح‌شده: مدیریت تم، منوی همبرگری، رندر کاربر/خریدها/تیکت‌ها، توست
// کامنت‌ها به فارسی برای قابل توسعه آسان

document.addEventListener('DOMContentLoaded', () => {
  // المنت‌ها
  const body = document.body;
  const menuToggle = document.getElementById('menu-toggle');
  const sideMenu = document.getElementById('side-menu');

  const themeToggle = document.getElementById('theme-toggle');
  const displayName = document.getElementById('display-name');
  const profileActionBtn = document.getElementById('profile-action');
  const editProfileBtn = document.getElementById('edit-profile');

  const welcomeName = document.getElementById('welcome-name');
  const welcomeText = document.getElementById('welcome-text');
  const lastLoginEl = document.getElementById('last-login');

  const purchaseListEl = document.getElementById('purchase-list');
  const ticketsListEl = document.getElementById('tickets-list');

  const toastEl = document.getElementById('toast');

  // داده نمونه - بعدا از Supabase دریافت خواهد شد
  const user = {
    id: 'user_123',
    name: 'علی',
    family: 'رضایی',
    email: 'ali@example.com',
    created_at: '2024-01-10',
    level: 'نقره‌ای', // 'برنزی' | 'نقره‌ای' | 'طلایی'
    isProfileComplete: true,
    lastLogin: '۱۴۰۳/۰۵/۲۰ ۱۲:۳۰',
    purchases: [
      { id: 'p1', title: 'برنامه مدیریت پروژه', desc: 'نسخه پرو', link: '#' },
      { id: 'p2', title: 'آموزش React از صفر', desc: 'دسترسی نامحدود', link: '#' }
    ],
    tickets: [
      { id: 't1', subject: 'افزایش سرعت سایت', body: 'لطفا بررسی شود', reply: 'در حال بررسی' }
    ]
  };

  /* ---------- توست (پیغام شناور) ---------- */
  let toastTimer;
  function showToast(message, type = 'info') {
    toastEl.textContent = message;
    toastEl.classList.add('show');
    // رنگ‌بندی ساده: برای اکنون از accent استفاده می‌کنیم؛ می‌توان بر اساس نوع رنگ تغییر داد
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toastEl.classList.remove('show');
    }, 3200);
  }

  /* ---------- منوی همبرگری ---------- */
  menuToggle.addEventListener('click', () => {
    const isOpen = sideMenu.classList.toggle('open');
    menuToggle.setAttribute('aria-expanded', String(isOpen));
  });

  /* ---------- مدیریت تم (localStorage) ---------- */
  function applyTheme(theme) {
    if (theme === 'dark') {
      body.classList.remove('theme-light');
      body.classList.add('theme-dark');
    } else {
      body.classList.remove('theme-dark');
      body.classList.add('theme-light');
    }
    localStorage.setItem('ui-theme', theme);
  }

  // بارگذاری تم ذخیره شده یا پیشفرض لایت
  const savedTheme = localStorage.getItem('ui-theme') || 'light';
  applyTheme(savedTheme);

  themeToggle.addEventListener('click', () => {
    const current = body.classList.contains('theme-dark') ? 'dark' : 'light';
    const next = current === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    showToast(`تم به ${next === 'dark' ? 'دارک' : 'لایت'} تغییر کرد`);
  });

  /* ---------- رندر اطلاعات کاربر ---------- */
  function renderProfile(u) {
    if (!u) return;
    const fullname = u.name && u.family ? `${u.name} ${u.family}` : 'کاربر عزیز';
    displayName.textContent = fullname;
    welcomeName.textContent = u.name || 'کاربر عزیز';
    lastLoginEl.textContent = `آخرین ورود: ${u.lastLogin || 'ثبت نشده'}`;
    document.getElementById('p-name').textContent = u.name || 'ثبت نشده';
    document.getElementById('p-family').textContent = u.family || 'ثبت نشده';
    document.getElementById('p-email').textContent = u.email || 'ثبت نشده';
    document.getElementById('p-created').textContent = u.created_at || '—';

    // سطح کاربری فارسی و نشان مدال
    const levelBadge = document.getElementById('level-badge');
    if (u.level === 'طلایی') {
      levelBadge.className = 'level-badge gold';
      levelBadge.textContent = 'طلایی';
    } else if (u.level === 'نقره‌ای') {
      levelBadge.className = 'level-badge silver';
      levelBadge.textContent = 'نقره‌ای';
    } else {
      levelBadge.className = 'level-badge bronze';
      levelBadge.textContent = 'برنزی';
    }

    // دکمه تکمیل یا ویرایش
    if (u.isProfileComplete) {
      profileActionBtn.innerHTML = '<i class="ri-pencil-line"></i><span class="btn-text">ویرایش اطلاعات</span>';
    } else {
      profileActionBtn.innerHTML = '<i class="ri-edit-line"></i><span class="btn-text">تکمیل پروفایل</span>';
    }
  }

  /* ---------- رندر خریدها ---------- */
  function renderPurchases(u) {
    purchaseListEl.innerHTML = '';
    if (!u || !u.purchases || u.purchases.length === 0) {
      purchaseListEl.innerHTML = `<div class="empty-note">خریدی یافت نشد.</div>`;
      return;
    }
    u.purchases.forEach(p => {
      const card = document.createElement('div');
      card.className = 'purchase-card';
      card.innerHTML = `
        <div class="p-head">
          <div class="p-thumb">📦</div>
          <div>
            <div class="p-title">${escapeHtml(p.title)}</div>
            <div class="p-desc muted">${escapeHtml(p.desc || '')}</div>
          </div>
        </div>
        <div class="p-actions">
          <button class="p-btn" data-link="${p.link}" data-id="${p.id}"><i class="ri-download-2-line"></i> دانلود</button>
        </div>
      `;
      purchaseListEl.appendChild(card);
    });

    // دکمه‌های دانلود کارتی
    purchaseListEl.querySelectorAll('.p-btn').forEach(btn=>{
      btn.addEventListener('click', (e)=>{
        const link = btn.dataset.link || '#';
        showToast('در حال انتقال به صفحه دانلود...');
        // در نسخه واقعی: window.open(link,'_blank')
        // برای تست فقط نمایش
        setTimeout(()=> window.open(link,'_blank'), 300);
      });
    });
  }

  /* ---------- رندر تیکت‌ها ---------- */
  function renderTickets(u) {
    ticketsListEl.innerHTML = '';
    if (!u || !u.tickets || u.tickets.length === 0) {
      ticketsListEl.innerHTML = `<div class="empty-note">تیکتی یافت نشد.</div>`;
      return;
    }
    u.tickets.forEach(t => {
      const c = document.createElement('div');
      c.className = 'ticket-card';
      c.innerHTML = `<p><strong>موضوع:</strong> ${escapeHtml(t.subject)}</p>
                     <p><strong>شرح:</strong> ${escapeHtml(t.body)}</p>
                     <p><strong>پاسخ:</strong> ${escapeHtml(t.reply || 'هنوز پاسخی داده نشده')}</p>`;
      ticketsListEl.appendChild(c);
    });
  }

  /* ---------- ایونت‌های دکمه‌ها ---------- */
  profileActionBtn.addEventListener('click', ()=> {
    showToast('در حال باز کردن فرم تکمیل/ویرایش پروفایل...');
    // TODO: ریدایرکت به صفحه تکمیل/ویرایش
  });
  editProfileBtn.addEventListener('click', ()=> {
    showToast('رفتن به صفحه تغییر اطلاعات...');
  });

  document.getElementById('support-btn').addEventListener('click', ()=> {
    showToast('باز شدن پنجره پشتیبانی...');
  });
  document.getElementById('new-ticket-btn').addEventListener('click', ()=> {
    showToast('فرم ثبت تیکت جدید باز شد...');
  });
  document.getElementById('logout-btn').addEventListener('click', ()=> {
    showToast('شما از حساب خارج شدید.');
    // TODO: فراخوانی supabase.auth.signOut() یا عملیات خروج
  });

  /* ---------- helper: ایمن‌سازی متن برای جلوگیری از XSS ---------- */
  function escapeHtml(s){
    return String(s || '').replace(/[&<>"']/g, (m)=> ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  }

  /* ---------- اجرای اولیه (render) ---------- */
  renderProfile(user);
  renderPurchases(user);
  renderTickets(user);

  // نمایش پیغام خوش آمد
  showToast('پنل شما آماده است — خوش آمدید!');
});
