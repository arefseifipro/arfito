/******************************************
 * نسخهٔ فارسی بازی حدس کشور — تک‌فایل
 * امکانات:
 * - همه چیز فارسی
 * - لیست کشورها به فارسی
 * - رفع باگ جابه‌جایی حروف با نرمال‌سازی و نگهداری اندیس‌ها
 * - ذخیره رکوردها در localStorage
 * - حالت سخت (تعداد فرصت کمتر + غیرفعال کردن دکمهٔ نمایش)
 * - صداهای کوتاه با WebAudio (بدون فایل خارجی)
 * - نمایش ایموجی/پرچم (قابل توسعه)
 *******************************************/

/* ---------- لیست کشورها (فارسی) ---------- */
const COUNTRIES = [
"افغانستان","البانی","الجزایر","اندورا","انگولا","ارژانتین","ارمنستان","استرالیا","اتریش","اذربایجان",
"باهاما","بحرین","بنگلادش","بلاروس","بلژیک","بلیز","بنین","بوتان","بولیوی",
"بوتسوانا","برزیل","برونئی","بلغارستان","بوروندی","کامبوج","کامرون","کانادا",
"شیلی","چین","کلمبیا","کومور","کاستاریکا","کرواسی","کوبا","قبرس","جمهوری چک","دانمارک","جیبوتی",
"دومینیکا","دومینیکن","اکوادور","مصر","السالوادور","استونی","اسواتینی","اتیوپی","فیجی","فنلاند",
"فرانسه","گابن","گامبیا","گرجستان","المان","غنا","یونان","گرنادا","گواتمالا","گینه","گویان","هائیتی",
"هندوراس","مجارستان","ایسلند","هند","اندونزی","ایران","عراق","ایرلند","ایتالیا","جامایکا","ژاپن",
"اردن","قزاقستان","کنیا","کوزوو","کویت","قرقیزستان","لائوس","لتونی","لبنان","لسوتو",
"لیبریا","لیبی","لتوانی","ماداگاسکار","مالاوی","مالزی","مالدیو","مالی",
"مالت","موریتانی","موریس","مکزیک","مولداوی","موناکو","مغولستان","مونته‌نگرو","مراکش","موزامبیک","میانمار",
"نامیبیا","نائورو","نپال","هلند","نیوزیلند","نیکاراگوئه","نیجر","نیجریه","کره شمالی","مقدونیه شمالی",
"نروژ","عمان","پاکستان","پالائو","پاناما","پاپوآ گینه نو","پاراگوئه","پرو","فیلیپین","لهستان","پرتغال",
"قطر","رومانی","روسیه","رواندا","سنت کیتس و نویس","سنت لوسیا","ساموآ","سان مارینو","عربستان","سنگال",
"صربستان","سیشل","سیرالئون","سنگاپور","اسلواکی","اسلوونی","سومالی","افریقای جنوبی",
"کره جنوبی","اسپانیا","سریلانکا","سودان","سورینام","سوئد","سوئیس","سوریه","تایوان","تاجیکستان","تانزانیا",
"تایلند","توگو","تونگا","تونس","ترکیه","ترکمنستان","تووالو","اوگاندا","اوکراین",
"امارات","بریتانیا","امریکا","اروگوئه","ازبکستان","وانواتو","واتیکان","ونزوئلا",
"ویتنام","یمن","زامبیا","زیمباوه"
];

/* ---------- نگهداری وضعیت بازی ---------- */
const intro = document.getElementById('intro');
const game = document.getElementById('game');
const manualInput = document.getElementById('manualInput');
const confirmManual = document.getElementById('confirmManual');
const randomBtn = document.getElementById('randomBtn');
const emojiBox = document.getElementById('emojiBox');
const wordLine = document.getElementById('wordLine');
const attemptsBox = document.getElementById('attemptsBox');
const wrongList = document.getElementById('wrongList');
const letterInput = document.getElementById('letterInput');
const guessLetterBtn = document.getElementById('guessLetter');
const wordInput = document.getElementById('wordInput');
const guessWordBtn = document.getElementById('guessWord');
const result = document.getElementById('result');
const revealBtn = document.getElementById('revealBtn');
const newBtn = document.getElementById('newBtn');
const lettersCountSpan = document.getElementById('lettersCount');
const themeToggle = document.getElementById('themeToggle');
const modeHardCheckbox = document.getElementById('modeHard');
const recordsBtn = document.getElementById('recordsBtn');
const recordsPanel = document.getElementById('recordsPanel');
const recordsList = document.getElementById('recordsList');
const clearRecordsBtn = document.getElementById('clearRecords');
const closeRecordsBtn = document.getElementById('closeRecords');
const topRecordsDiv = document.getElementById('topRecords');

let target = "";
let normalized = ""; // برای مقایسهٔ کلی
let displayChars = []; // {char, norm, isSpace/sep, revealed}
let attempts = 0;
let wrongGuesses = new Set();
let correctGuesses = new Set();
let finished = false;
let isHard = false;

/* ---------- تنظیمات محلی (localStorage) ---------- */
const STORAGE_KEY = 'arfito_country_guess_records_v1';
const PREFS_KEY = 'arfito_country_guess_prefs_v1';

function loadPrefs(){
    try{
    const p = JSON.parse(localStorage.getItem(PREFS_KEY) || '{}');
    if(p.theme) document.body.className = p.theme;
    if(p.theme) themeToggle.value = p.theme;
    if(p.hard) modeHardCheckbox.checked = true;
    }catch(e){}
}
function savePrefs(){
    const p = { theme: document.body.className, hard: modeHardCheckbox.checked };
    localStorage.setItem(PREFS_KEY, JSON.stringify(p));
}

/* ---------- نرمال‌سازی حروف (برطرف‌کنندهٔ باگ ترتیب) ---------- */
function normalizeString(s){
    if(!s) return '';
    // حذف کاراکترهای مخفی / فاصلهٔ زائد، تبدیل به lowercase
    let t = String(s).trim().replace(/\u200B/g,'').replace(/\u200C/g,'').replace(/\u200D/g,'');
    // تبدیل برخی حروف عربی به معادل فارسی برای تطابق بهتر
    t = t.replace(/ي/g,'ی').replace(/ي/g,'ی').replace(/ك/g,'ک').replace(/ۀ/g,'ه').replace(/ؤ/g,'و').replace(/ء/g,'').replace(/ٱ/g,'ا');
    // حذف اعراب کوچک (Tashkeel)
    t = t.replace(/[\u064B-\u065F\u0670]/g,'');
    return t.toLowerCase();
}

function normalizeChar(ch){
    return normalizeString(ch);
}

/* ---------- آماده‌سازی آرایهٔ نمایش (حفظ اندیس‌ها) ---------- */
function prepareDisplayArr(name){
    displayChars = [];
    // استفاده از Array.from برای پشتیبانی از کاراکترهای یونی‌کد
    const arr = Array.from(name);
    arr.forEach(ch => {
    // فاصله یا خط تیره یا اسلش یا پرانتز را به‌عنوان جداکننده در نظر می‌گیریم و نمایش‌شده قرار می‌دهیم
    const isSeparator = /\s|[-–—,()\/،]/.test(ch);
    const norm = normalizeChar(ch);
    displayChars.push({
        char: ch,
        norm: norm, // برای مقایسه حرف به حرف
        isSep: isSeparator,
        revealed: isSeparator
    });
    });
}

function countLettersOnly(){
    return displayChars.filter(it => !it.isSep && /\p{L}/u.test(it.char)).length;
}

/* ---------- رندر کردن کلمه (بدون جابه‌جایی اندیس) ---------- */
function renderWordLine(){
    wordLine.innerHTML = '';
    displayChars.forEach(item => {
    const box = document.createElement('div');
    box.className = item.isSep ? 'char-space' : 'char-box';
    if(item.isSep){
        box.innerHTML = '&nbsp;';
    } else if(item.revealed){
        const span = document.createElement('span');
        span.className = 'char-filled';
        span.textContent = item.char;
        box.appendChild(span);
    } else {
        box.textContent = '';
    }
    wordLine.appendChild(box);
    });
}

/* ---------- به‌روز‌رسانی UI و لیست اشتباهات ---------- */
function updateUI(){
    attemptsBox.textContent = attempts;
    lettersCountSpan.textContent = countLettersOnly();
    wrongList.innerHTML = '';
    Array.from(wrongGuesses).forEach(ch => {
    const pill = document.createElement('div');
    pill.className = 'wrong-pill';
    pill.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" style="opacity:0.95"><path fill="currentColor" d="M18.3 5.71a1 1 0 00-1.41 0L12 10.59 7.11 5.7A1 1 0 105.7 7.11L10.59 12l-4.9 4.89a1 1 0 101.41 1.42L12 13.41l4.89 4.9a1 1 0 001.42-1.41L13.41 12l4.9-4.89a1 1 0 000-1.4z"/></svg> ${ch.toUpperCase()}`;
    wrongList.appendChild(pill);
    });
}

/* ---------- بررسی برد/باخت ---------- */
function checkWin(){
    const all = displayChars.every(it => it.isSep || it.revealed);
    if(all){
    finished = true;
    onWin();
    }
}

function showResultMessage(isWin, text){
    result.className = '';
    result.classList.add(isWin ? 'win' : 'lose');
    result.classList.remove('hidden');
    result.textContent = text;
}

function revealAll(){
    displayChars.forEach(it => { if(!it.isSep) it.revealed = true; });
    renderWordLine();
}

/* ---------- شروع بازی با یک نام ---------- */
function startGameWith(name){
    target = name;
    normalized = normalizeString(name);
    prepareDisplayArr(name);
    const letters = countLettersOnly();
    // تعیین تعداد فرصت
    attempts = isHard ? Math.max(1, Math.ceil(letters / 2)) : (letters + 2);
    wrongGuesses = new Set();
    correctGuesses = new Set();
    finished = false;
    // ایموجی/پرچم
    emojiBox.textContent = chooseEmojiForCountry(name);
    result.classList.add('hidden');
    // نمایش/مخفی
    intro.classList.add('hidden');
    game.classList.remove('hidden');
    renderWordLine();
    updateUI();
    letterInput.value = '';
    wordInput.value = '';
    setTimeout(() => letterInput.focus(), 120);
    refreshTopRecordsUI();
}

/* ---------- انتخاب تصادفی ---------- */
function pickRandom(arr){ return arr[Math.floor(Math.random()*arr.length)]; }

/* ---------- ایموجی/پرچم ساده (قابل توسعه با API) ---------- */
  const EMOJI_MAP = {
      "ملانونیا":"IP"
    };
function chooseEmojiForCountry(name){
    const key = normalizeString(name);
    for(const k in EMOJI_MAP){
    if(key.includes(normalizeString(k))) return EMOJI_MAP[k];
    }
    if(key.includes('متحد')) return '🌐';
    return '🌍';
}

/* ---------- صداها (WebAudio) ---------- */
const AudioCtx = window.AudioContext || window.webkitAudioContext;
let audioCtx = null;
function playTone(freq, duration=0.12, type='sine'){
    if(!AudioCtx) return;
    if(!audioCtx) audioCtx = new AudioCtx();
    const o = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    o.type = type;
    o.frequency.value = freq;
    o.connect(g);
    g.connect(audioCtx.destination);
    g.gain.setValueAtTime(0.0001, audioCtx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.12, audioCtx.currentTime + 0.01);
    o.start();
    g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + duration);
    setTimeout(()=>{ try{ o.stop(); }catch(e){} }, (duration+0.02)*1000);
}
function playSuccess(){ playTone(880, 0.15, 'sine'); playTone(1320, 0.12, 'sine'); }
function playError(){ playTone(220, 0.18, 'sawtooth'); }

/* ---------- منطق حدس حرف ---------- */
function handleLetterGuess(){
    if(finished) return;
    const raw = letterInput.value.trim();
    letterInput.value = '';
    if(!raw) return;
    const guess = normalizeChar(raw[0] || raw); // اولین کاراکتر
    if(!guess) return;
    // اگر قبلاً حدس زده شده
    if(correctGuesses.has(guess) || wrongGuesses.has(guess)) return;
    // بررسی وجود در نام (مقایسه‌ی norm هر المنت)
    let found = false;
    for(let i=0;i<displayChars.length;i++){
    const it = displayChars[i];
    // مقایسه نرمال‌شدهٔ هر کاراکتر با حدس
    if(!it.isSep && it.norm && it.norm === guess){
        it.revealed = true;
        found = true;
    }
    }
    if(found){
    correctGuesses.add(guess);
    renderWordLine();
    updateUI();
    playSuccess();
    checkWin();
    } else {
    wrongGuesses.add(guess.toUpperCase());
    attempts = Math.max(0, attempts - 1);
    updateUI();
    playError();
    if(attempts <= 0){
        finished = true;
        revealAll();
        onLose();
    }
    }
}

/* ---------- منطق حدس کلمه کامل ---------- */
function handleWordGuess(){
    if(finished) return;
    const raw = wordInput.value.trim();
    wordInput.value = '';
    if(!raw) return;
    const guessNorm = normalizeString(raw);
    if(guessNorm === normalized){
    // برد
    displayChars.forEach(it => { if(!it.isSep) it.revealed = true; });
    renderWordLine();
    finished = true;
    onWin();
    } else {
    // اشتباه: کسر یک فرصت و ثبت اشتباه (نمایش کلمهٔ اشتباه در لیست)
    attempts = Math.max(0, attempts - 1);
    wrongGuesses.add(guessNorm.toUpperCase());
    updateUI();
    playError();
    if(attempts <= 0){
        finished = true;
        revealAll();
        onLose();
    }
    }
}

/* ---------- رفتار هنگام برد/باخت و ذخیره رکورد ---------- */
function onWin(){
    const msg = `آفرین! درست حدس زدی — «${target}».`;
    showResultMessage(true, msg);
    playSuccess();
    saveRecord({ country: target, attemptsLeft: attempts, letters: countLettersOnly(), mode: isHard ? 'سخت' : 'عادی', at: new Date().toISOString() });
    refreshTopRecordsUI();
}

function onLose(){
    const msg = `متاسفانه باختی — کشور «${target}» بود.`;
    showResultMessage(false, msg);
    playError();
    saveRecord({ country: target, attemptsLeft: 0, letters: countLettersOnly(), mode: isHard ? 'سخت' : 'عادی', at: new Date().toISOString() });
    refreshTopRecordsUI();
}

/* ---------- ذخیره و نمایش رکوردها (localStorage) ---------- */
function loadRecords(){
    try{
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    }catch(e){
    return [];
    }
}
function saveRecords(arr){
    localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
}
function saveRecord(rec){
    try{
    const arr = loadRecords();
    arr.push(rec);
    // مرتب‌سازی بر اساس attemptsLeft (بیشتر بهتر) و سپس تعداد حروف کمتر (توی مساوی)
    arr.sort((a,b)=> {
        if(b.attemptsLeft !== a.attemptsLeft) return b.attemptsLeft - a.attemptsLeft;
        return a.letters - b.letters;
    });
    // نگه داشتن تا 20 رکورد آخر
    const sliced = arr.slice(0,20);
    saveRecords(sliced);
    }catch(e){}
}
function renderRecordsList(){
    const arr = loadRecords();
    if(!arr.length){
    recordsList.innerHTML = '<div class="small muted">هنوز رکوردی ثبت نشده است.</div>';
    return;
    }
    recordsList.innerHTML = '';
    arr.forEach((r, idx) => {
    const el = document.createElement('div');
    el.className = 'small';
    const date = (new Date(r.at)).toLocaleString();
    el.textContent = `${idx+1}. ${r.country} — فرصت باقی: ${r.attemptsLeft} — حالت: ${r.mode} — ${date}`;
    recordsList.appendChild(el);
    });
}

function refreshTopRecordsUI(){
    const arr = loadRecords().slice(0,5);
    topRecordsDiv.innerHTML = '';
    if(!arr.length){
    topRecordsDiv.innerHTML = '<div class="small muted">هنوز رکوردی ثبت نشده است.</div>';
    return;
    }
    arr.forEach((r, idx) => {
    const div = document.createElement('div');
    div.className = 'small';
    div.textContent = `${idx+1}. ${r.country} — فرصت: ${r.attemptsLeft} — ${r.mode}`;
    topRecordsDiv.appendChild(div);
    });
}

/* ---------- event listeners ---------- */
confirmManual.addEventListener('click', () => {
    const v = manualInput.value.trim();
    if(!v){ alert('لطفاً نام یک کشور وارد کنید.'); return; }
    startGameWith(v);
});

randomBtn.addEventListener('click', () => {
    const c = pickRandom(COUNTRIES);
    startGameWith(c);
});

guessLetterBtn.addEventListener('click', handleLetterGuess);
letterInput.addEventListener('keydown', (e) => { if(e.key === 'Enter') handleLetterGuess(); });

guessWordBtn.addEventListener('click', handleWordGuess);
wordInput.addEventListener('keydown', (e) => { if(e.key === 'Enter') handleWordGuess(); });

revealBtn.addEventListener('click', () => {
    if(isHard) return; // در حالت سخت غیر فعال باشد
    revealAll();
    showResultMessage(false, `کشور: «${target}» (نمایش داده شد).`);
    finished = true;
});

newBtn.addEventListener('click', () => {
    // بازگشت به صفحهٔ اول
    intro.classList.remove('hidden');
    game.classList.add('hidden');
    manualInput.value = '';
    result.classList.add('hidden');
});

// prevent multi-char in letter input (پشتیبانی از حرف‌های ترکیبی تا 2)
letterInput.addEventListener('input', () => {
    if(letterInput.value.length > 2) letterInput.value = letterInput.value.slice(0,2);
});

// theme & mode
themeToggle.addEventListener('change', () => {
    document.body.className = themeToggle.value;
    savePrefs();
});
modeHardCheckbox.addEventListener('change', () => {
    isHard = modeHardCheckbox.checked;
    savePrefs();
});

// records panel
recordsBtn.addEventListener('click', () => {
    recordsPanel.classList.toggle('hidden');
    if(!recordsPanel.classList.contains('hidden')) renderRecordsList();
});
closeRecordsBtn.addEventListener('click', () => recordsPanel.classList.add('hidden'));
clearRecordsBtn.addEventListener('click', () => {
    if(confirm('آیا مطمئنی رکوردها حذف شوند؟')){ localStorage.removeItem(STORAGE_KEY); renderRecordsList(); refreshTopRecordsUI(); }
});

// keyboard shortcut: '/' برای فوکوس روی حدس حرف
document.addEventListener('keydown', (e) => {
    if(e.key === '/' && !finished && !game.classList.contains('hidden')){ e.preventDefault(); letterInput.focus(); }
});

/* ---------- initial setup ---------- */
function init(){
    loadPrefs();
    isHard = modeHardCheckbox.checked;
    savePrefs();
    refreshTopRecordsUI();
    renderRecordsList();
    // small UX: اگر بخوان از اینپوت دستی استفاده کنند با Enter شروع شود
    manualInput.addEventListener('keydown', (e)=>{ if(e.key==='Enter') confirmManual.click(); });
}
init();
